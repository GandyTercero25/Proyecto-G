import java.util.Date;

public interface IUsuario {
    void registrarAnimal(String nombreAnimal, String codigoRegistro);

    Date getFechaUltimoRegistro();

    int getCantidadAnimalesRegistrados();

    Animal getUltimoAnimalRegistrado();

    boolean adoptarAnimal(Animal animalAAdoptar, String nombreAdoptante, String numeroCelular, String cedulaAdoptante, String direccionAdopcion);

    boolean esAnimalAdoptado(Animal animal);

    boolean realizarAdopcion(Animal animal, String nombreAdoptante, String numeroCelular, String cedulaAdoptante, String direccionAdopcion);
}
