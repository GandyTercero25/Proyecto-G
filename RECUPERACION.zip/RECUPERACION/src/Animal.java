import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Animal {
    private String nombre;
    private Date fechaRegistro;
    private Date fechaNacimiento; // Agregamos el campo fechaNacimiento
    private String codigoRegistro;
    private int edad;
    private boolean esSaludable;

    public Animal(String nombre, Date fechaRegistro, Date fechaNacimiento, String codigoRegistro, boolean esSaludable) {
        this.nombre = nombre;
        this.fechaRegistro = fechaRegistro;
        this.fechaNacimiento = fechaNacimiento;
        this.codigoRegistro = codigoRegistro;
        this.esSaludable = esSaludable;
        this.edad = edad;
    }
    public String getNombre() {
        return nombre;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public String getFechaRegistroFormatted() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        return dateFormat.format(fechaRegistro);
    }

    public String getHoraRegistro() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(fechaRegistro);

        int hora = calendar.get(Calendar.HOUR_OF_DAY);
        int minutos = calendar.get(Calendar.MINUTE);
        int segundos = calendar.get(Calendar.SECOND);

        return String.format("%02d:%02d:%02d", hora, minutos, segundos);
    }
    public int calcularEdadEnAnios() {
        Calendar fechaNacimientoCalendar = Calendar.getInstance();
        fechaNacimientoCalendar.setTime(fechaNacimiento);
        Calendar fechaActual = Calendar.getInstance();

        int edad = fechaActual.get(Calendar.YEAR) - fechaNacimientoCalendar.get(Calendar.YEAR);

        // Si el día actual es anterior al día de nacimiento, restamos un año
        if (fechaActual.get(Calendar.DAY_OF_YEAR) < fechaNacimientoCalendar.get(Calendar.DAY_OF_YEAR)) {
            edad--;
        }

        return edad;
    }
    private int calcularEdad(Date fechaNacimiento) {
        if (fechaNacimiento == null) {
            return 0;
        }

        Calendar fechaActual = Calendar.getInstance();
        Calendar fechaNac = Calendar.getInstance();
        fechaNac.setTime(fechaNacimiento);

        int edad = fechaActual.get(Calendar.YEAR) - fechaNac.get(Calendar.YEAR);
        if (fechaActual.get(Calendar.MONTH) < fechaNac.get(Calendar.MONTH)
                || (fechaActual.get(Calendar.MONTH) == fechaNac.get(Calendar.MONTH)
                && fechaActual.get(Calendar.DAY_OF_MONTH) < fechaNac.get(Calendar.DAY_OF_MONTH))) {
            edad--;
        }

        return edad;
    }

    public int getEdad() {
        return calcularEdad(fechaNacimiento);
    }

    public String getCodigoRegistro() {
        return codigoRegistro;
    }

    public boolean esSaludable() {
        return esSaludable;
    }


    public String getNombreAdoptante() {
        return null;
    }

    public String getNumeroCelularAdoptante() {
        return null;
    }

    public String getCedulaAdoptante() {
        return null;
    }

    public String getDireccionAdopcion() {
        return null;
    }

    public boolean esAdoptado() {
        return getNombreAdoptante() != null || getNumeroCelularAdoptante() != null ||
                getCedulaAdoptante()  != null || getDireccionAdopcion() != null;
    }

}

