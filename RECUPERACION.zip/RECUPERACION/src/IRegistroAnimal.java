import java.util.Date;
import java.util.List;

public interface IRegistroAnimal {
    void registrarAnimal(String nombreAnimal, Date fechaRegistro, Date fechaNacimiento, String codigoRegistro);
    List<Animal> getAnimalesRegistrados();
    Animal getUltimoAnimalRegistrado();
    int getNumeroAnimalesRegistrados();
    Animal buscarAnimalPorCodigo(String codigoAnimal);
    List<Animal> getAnimalesDisponiblesParaAdopcion();
}
