import java.util.*;

public class RegistroAnimal implements IRegistroAnimal {
    private List<Animal> animalesRegistrados;
    private Map<String, Animal> codigoRegistroMap;
    private Scanner scanner;

    public RegistroAnimal() {
        this.animalesRegistrados = new ArrayList<>();
        this.codigoRegistroMap = new HashMap<>();
        this.scanner = new Scanner(System.in); // Agregar esta línea para inicializar el Scanner
    }

    @Override
    public void registrarAnimal(String nombreAnimal, Date fechaRegistro, Date fechaNacimiento, String codigoRegistro) {
        // Verificar si el código de registro ya existe
        if (codigoRegistroMap.containsKey(codigoRegistro)) {
            System.out.println("El código de registro ya existe. No se puede registrar el animal.");
            return;
        }
        System.out.print("Es el animal saludable? (S/N): ");
        String respuesta = scanner.nextLine().trim();
        boolean esSaludable = respuesta.equalsIgnoreCase("S");

        Animal nuevoAnimal = new Animal(nombreAnimal, fechaRegistro, fechaNacimiento, codigoRegistro, esSaludable);
        animalesRegistrados.add(nuevoAnimal);
        codigoRegistroMap.put(codigoRegistro, nuevoAnimal);
    }

    @Override
    public List<Animal> getAnimalesRegistrados() {
        List<Animal> animalesDisponibles = new ArrayList<>();
        for(Animal animal: animalesRegistrados ){
            if(!animal.esAdoptado() && animal.esSaludable()){
                animalesDisponibles.add(animal);
            }
        }
        return animalesRegistrados;
    }

    @Override
    public Animal getUltimoAnimalRegistrado() {
        if (animalesRegistrados.isEmpty()) {
            return null;
        }
        return animalesRegistrados.get(animalesRegistrados.size() - 1);
    }

    @Override
    public int getNumeroAnimalesRegistrados() {
        return animalesRegistrados.size();
    }

    @Override
    public Animal buscarAnimalPorCodigo(String codigoAnimal) {
        return codigoRegistroMap.get(codigoAnimal);
    }

    @Override
    public List<Animal> getAnimalesDisponiblesParaAdopcion() {
        List<Animal> animalesDisponibles = new ArrayList<>();
        for (Animal animal : animalesRegistrados) {
            if (!animal.esAdoptado() && animal.esSaludable()) {
                animalesDisponibles.add(animal);
            }
        }
        return animalesDisponibles;
    }

}
