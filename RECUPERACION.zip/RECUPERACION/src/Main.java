import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws ParseException {
        List<Usuario> usuariosRegistrados = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Bienvenido al registro de usuarios");
        System.out.print("Ingrese el nombre de usuario: ");
        String nombre = scanner.nextLine();

        System.out.print("Ingresar el apellido del usuario: ");
        String apellido = scanner.nextLine();

        System.out.print("Ingrese la cédula: ");
        String cedula = scanner.nextLine();

        System.out.print("Ingresar contraseña: ");
        String contraseña = scanner.nextLine();

        Usuario nuevoUsuario = new Usuario(nombre, apellido, cedula, contraseña);
        usuariosRegistrados.add(nuevoUsuario);

        System.out.println("Usuario registrado correctamente.");
        System.out.println("Nombre de usuario: " + nombre);
        System.out.println("Apellido: " + apellido);
        System.out.println("Cédula: " + cedula);
        System.out.println("Contraseña: " + contraseña);

        RegistroAnimal registroAnimal = new RegistroAnimal();

        while (true) {
            System.out.println("\n=== Menú ===");
            System.out.println("1. Registrar un animal");
            System.out.println("2. Cantidad de animales registrados");
            System.out.println("3. Último animal registrado");
            System.out.println("4. Adopciones");
            System.out.println("5. Mostrar animales disponibles para adopción");
            System.out.println("6. Salir");
            System.out.print("Ingrese una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumimos el salto de línea después de leer el entero

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del animal: ");
                    String nombreAnimal = scanner.nextLine();

                    System.out.print("Ingrese el código de registro del animal: ");
                    String codigoRegistro = scanner.nextLine();

                    // Obtener la fecha actual
                    Date fechaRegistro = new Date();

                    System.out.print("Ingrese la fecha de nacimiento del animal (formato dd/MM/yyyy): ");
                    String fechaNacimientoStr = scanner.nextLine();

                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    Date fechaNacimiento = dateFormat.parse(fechaNacimientoStr);

                    registroAnimal.registrarAnimal(nombreAnimal, fechaRegistro, fechaNacimiento, codigoRegistro);
                    System.out.println("Animal registrado con éxito.");
                    break;
                case 2:
                    List<Animal> animalesRegistrados = registroAnimal.getAnimalesRegistrados();
                    System.out.println("Cantidad total de animales registrados: " + animalesRegistrados.size());
                    for (Animal animal : animalesRegistrados) {
                        System.out.println("Nombre del animal: " + animal.getNombre());
                        System.out.println("Código de registro: " + animal.getCodigoRegistro());
                        System.out.println("Fecha y hora de ingreso: " + animal.getFechaRegistroFormatted() + " " + animal.getHoraRegistro());
                        System.out.println("Edad del animal: " + animal.getEdad() + " años");
                        System.out.println("---------------------");
                    }
                    break;
                case 3:
                    Animal ultimoAnimalRegistrado = registroAnimal.getUltimoAnimalRegistrado();
                    if (ultimoAnimalRegistrado != null) {
                        System.out.println("Último animal registrado: " + ultimoAnimalRegistrado.getNombre());
                        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                        String fechaUltimoRegistro = dateFormat.format(ultimoAnimalRegistrado.getFechaRegistro());
                        String codigoUltimoRegistro = ultimoAnimalRegistrado.getCodigoRegistro();
                        System.out.println("Fecha del último animal registrado: " + fechaUltimoRegistro);
                        System.out.println("Hora del último animal registrado: " + ultimoAnimalRegistrado.getHoraRegistro());
                        System.out.println("Código del último animal registrado: " + codigoUltimoRegistro);
                    } else {
                        System.out.println("No se han registrado animales.");
                    }
                    break;
                case 4:
                    // Realizar adopción
                    System.out.print("Ingrese el código del animal a adoptar: ");
                    String codigoAnimal = scanner.nextLine();

                    Animal animalAAdoptar = registroAnimal.buscarAnimalPorCodigo(codigoAnimal);

                    if (animalAAdoptar != null) {
                        System.out.print("Ingrese el nombre del adoptante: ");
                        String nombreAdoptante = scanner.nextLine();

                        System.out.print("Ingrese el número de celular del adoptante: ");
                        String numeroCelular = scanner.nextLine();

                        System.out.print("Ingrese la cédula del adoptante: ");
                        String cedulaAdoptante = scanner.nextLine();

                        System.out.print("Ingrese la dirección de adopción: ");
                        String direccionAdopcion = scanner.nextLine();

                        boolean adopcionExitosa = nuevoUsuario.adoptarAnimal(animalAAdoptar, nombreAdoptante, numeroCelular, cedulaAdoptante, direccionAdopcion);

                        if (adopcionExitosa) {
                            System.out.println("Adopción realizada con éxito.");
                        } else {
                            System.out.println("No se pudo realizar la adopción.");
                        }
                    } else {
                        System.out.println("El animal con el código " + codigoAnimal + " no está registrado.");
                    }
                    break;
                case 5:
                    // Mostrar animales disponibles para adopción
                    List<Animal> animalesDisponibles = registroAnimal.getAnimalesDisponiblesParaAdopcion();
                    if (animalesDisponibles.isEmpty()) {
                        System.out.println("No hay animales disponibles para adopción en este momento.");
                    } else {
                        System.out.println("Animales disponibles para adopción:");
                        for (Animal animal : animalesDisponibles) {
                            System.out.println("Nombre del animal: " + animal.getNombre());
                            System.out.println("Código de registro: " + animal.getCodigoRegistro());
                            System.out.println("Fecha y hora de ingreso: " + animal.getFechaRegistroFormatted() + " " + animal.getHoraRegistro());
                            System.out.println("---------------------");
                        }
                    }
                    break;
                case 6:
                    System.out.println("Saliendo del programa.");
                    return;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
    }
}
