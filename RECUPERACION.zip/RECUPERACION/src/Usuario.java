import java.util.Date;
import java.util.List;
import java.util.ArrayList;

public class Usuario implements IUsuario {
    private String nombre;
    private String apellido;
    private String cedula;
    private String contraseña;
    private List<RegistroAnimal> registrosAnimales;

    public Usuario(String nombre, String apellido, String cedula, String contraseña) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.contraseña = contraseña;
        this.registrosAnimales = new ArrayList<>(); // Se inicializa la lista correctamente
    }

    // ... otros métodos y getters/setters ...

    @Override
    public void registrarAnimal(String nombreAnimal, String codigoRegistro) {
        RegistroAnimal registroAnimal;
        if (registrosAnimales.isEmpty()) {
            registroAnimal = new RegistroAnimal();
            registrosAnimales.add(registroAnimal);
        } else {
            registroAnimal = registrosAnimales.get(registrosAnimales.size() - 1);
        }
        registroAnimal.registrarAnimal(nombreAnimal, new Date(), null, codigoRegistro);
    }

    @Override
    public Date getFechaUltimoRegistro() {
        if (registrosAnimales.isEmpty()) {
            return null;
        }
        RegistroAnimal ultimoRegistro = registrosAnimales.get(registrosAnimales.size() - 1);
        Animal ultimoAnimal = ultimoRegistro.getUltimoAnimalRegistrado();
        return ultimoAnimal.getFechaRegistro();
    }

    @Override
    public int getCantidadAnimalesRegistrados() {
        return registrosAnimales.stream().mapToInt(RegistroAnimal::getNumeroAnimalesRegistrados).sum();
    }

    @Override
    public Animal getUltimoAnimalRegistrado() {
        if (registrosAnimales.isEmpty()) {
            return null;
        }
        RegistroAnimal ultimoRegistro = registrosAnimales.get(registrosAnimales.size() - 1);
        return ultimoRegistro.getUltimoAnimalRegistrado();
    }

    @Override
    public boolean adoptarAnimal(Animal animalAAdoptar, String nombreAdoptante, String numeroCelular, String cedulaAdoptante, String direccionAdopcion) {
        // Lógica para realizar la adopción del animal
        // Retorna true si la adopción fue exitosa, de lo contrario, false
        // Implementa la lógica para adoptar el animal y actualiza los registros
        return true;
    }

    @Override
    public boolean esAnimalAdoptado(Animal animal) {
        return animal.getNombreAdoptante() != null || animal.getNumeroCelularAdoptante() != null ||
                animal.getCedulaAdoptante() != null || animal.getDireccionAdopcion() != null;
    }

    @Override
    public boolean realizarAdopcion(Animal animal, String nombreAdoptante, String numeroCelular, String cedulaAdoptante, String direccionAdopcion) {
        if (!animal.esSaludable()) {
            System.out.println("El animal no es saludable. No se puede realizar la adopción.");
            return false;
        }
        // Completa la lógica para realizar la adopción y actualizar los registros
        return true;
    }
}
